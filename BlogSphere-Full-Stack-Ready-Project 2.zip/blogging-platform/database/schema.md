# Database Design

MongoDB database: `blogsphere`

## Collections

### users

```text
_id
name
email
password
bio
createdAt
updatedAt
```

### posts

```text
_id
title
content
excerpt
category
status
author -> users._id
createdAt
updatedAt
```

### comments

```text
_id
text
author -> users._id
post -> posts._id
createdAt
updatedAt
```

## Relationships

User 1 ---- many Posts

User 1 ---- many Comments

Post 1 ---- many Comments

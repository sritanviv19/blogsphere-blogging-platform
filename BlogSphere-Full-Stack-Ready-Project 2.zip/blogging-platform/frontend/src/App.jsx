import React, { useEffect, useState } from "react";
import { Routes, Route, Link, useNavigate, useParams } from "react-router-dom";
import api from "./api";

const getUser = () => JSON.parse(localStorage.getItem("user") || "null");

function Layout({ children }) {
  const nav = useNavigate();
  const user = getUser();

  const logout = () => {
    localStorage.clear();
    nav("/");
    window.location.reload();
  };

  return (
    <>
      <nav className="nav">
        <Link className="logo" to="/">BlogSphere</Link>
        <div className="navlinks">
          <Link to="/">Home</Link>
          {user ? (
            <>
              <Link to="/dashboard">Dashboard</Link>
              <Link to="/create">Write</Link>
              <Link to={`/profile/${user.id}`}>Profile</Link>
              <button className="ghost" onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link className="button small" to="/register">Join</Link>
            </>
          )}
        </div>
      </nav>
      <main className="container">{children}</main>
      <footer>© 2026 BlogSphere · Full Stack B.Tech Project</footer>
    </>
  );
}

function Home() {
  const [posts, setPosts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async (term = "") => {
    setLoading(true);
    const r = await api.get(`/posts${term ? `?search=${encodeURIComponent(term)}` : ""}`);
    setPosts(r.data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <>
      <section className="hero">
        <div>
          <span className="eyebrow">WRITE · SHARE · DISCOVER</span>
          <h1>Ideas deserve<br /><em>a place to live.</em></h1>
          <p>BlogSphere is a simple blogging community where students and creators can publish ideas, learn from others, and start meaningful conversations.</p>
          <Link className="button" to={getUser() ? "/create" : "/register"}>Start Writing →</Link>
        </div>
      </section>

      <div className="sectionHead">
        <div><span className="eyebrow">LATEST STORIES</span><h2>Explore the community</h2></div>
        <form onSubmit={e => { e.preventDefault(); load(search); }} className="search">
          <input placeholder="Search posts..." value={search} onChange={e => setSearch(e.target.value)} />
          <button className="button small">Search</button>
        </form>
      </div>

      {loading ? <p>Loading stories...</p> :
      <div className="postGrid">
        {posts.map(post => <PostCard key={post._id} post={post} />)}
      </div>}
      {!loading && !posts.length && <div className="empty">No published posts found.</div>}
    </>
  );
}

function PostCard({ post }) {
  return (
    <article className="postCard">
      <span className="tag">{post.category}</span>
      <h3>{post.title}</h3>
      <p>{post.excerpt || post.content.slice(0, 150) + "..."}</p>
      <div className="meta">
        <span>By {post.author?.name}</span>
        <span>{new Date(post.createdAt).toLocaleDateString()}</span>
      </div>
      <Link to={`/post/${post._id}`} className="read">Read story →</Link>
    </article>
  );
}

function Auth({ register = false }) {
  const nav = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  const submit = async e => {
    e.preventDefault();
    try {
      const endpoint = register ? "/auth/register" : "/auth/login";
      const r = await api.post(endpoint, form);
      localStorage.setItem("token", r.data.token);
      localStorage.setItem("user", JSON.stringify(r.data.user));
      nav("/");
      window.location.reload();
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="auth">
      <div className="formCard">
        <span className="eyebrow">{register ? "WELCOME" : "WELCOME BACK"}</span>
        <h2>{register ? "Create your account" : "Sign in to BlogSphere"}</h2>
        {error && <div className="error">{error}</div>}
        <form onSubmit={submit}>
          {register && <input placeholder="Full name" required value={form.name} onChange={e => setForm({...form,name:e.target.value})}/>}
          <input type="email" placeholder="Email address" required value={form.email} onChange={e => setForm({...form,email:e.target.value})}/>
          <input type="password" placeholder="Password (6+ characters)" required minLength="6" value={form.password} onChange={e => setForm({...form,password:e.target.value})}/>
          <button className="button">{register ? "Create account" : "Login"} →</button>
        </form>
        <p className="muted">{register ? "Already have an account?" : "New here?"} <Link to={register ? "/login" : "/register"}>{register ? "Login" : "Create one"}</Link></p>
      </div>
    </div>
  );
}

function PostDetail() {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [text, setText] = useState("");
  const user = getUser();

  const load = async () => {
    const [p, c] = await Promise.all([api.get(`/posts/${id}`), api.get(`/comments/post/${id}`)]);
    setPost(p.data); setComments(c.data);
  };
  useEffect(() => { load(); }, [id]);

  const comment = async e => {
    e.preventDefault();
    if (!user) return alert("Please login to comment.");
    await api.post(`/comments/post/${id}`, { text });
    setText(""); load();
  };

  if (!post) return <p>Loading story...</p>;

  return (
    <article className="detail">
      <span className="tag">{post.category}</span>
      <h1>{post.title}</h1>
      <div className="meta">By <Link to={`/profile/${post.author._id}`}>{post.author.name}</Link> · {new Date(post.createdAt).toLocaleString()}</div>
      <div className="content">{post.content.split("\n").map((p,i)=><p key={i}>{p}</p>)}</div>

      <section className="comments">
        <h2>Comments ({comments.length})</h2>
        {user ? (
          <form onSubmit={comment} className="commentForm">
            <textarea placeholder="Share your thoughts..." value={text} onChange={e=>setText(e.target.value)} required />
            <button className="button small">Comment</button>
          </form>
        ) : <p className="muted">Login to join the conversation.</p>}

        {comments.map(c => <div className="comment" key={c._id}>
          <b>{c.author.name}</b><span>{new Date(c.createdAt).toLocaleString()}</span>
          <p>{c.text}</p>
          {user && user.id === c.author._id && <button className="delete" onClick={async()=>{await api.delete(`/comments/${c._id}`);load()}}>Delete</button>}
        </div>)}
      </section>
    </article>
  );
}

function Editor() {
  const nav = useNavigate();
  const { id } = useParams();
  const editing = Boolean(id);
  const [form, setForm] = useState({ title:"", excerpt:"", category:"Technology", content:"", status:"published" });
  const [error, setError] = useState("");

  useEffect(() => {
    if (editing) api.get(`/posts/${id}`).then(r => setForm({
      title:r.data.title, excerpt:r.data.excerpt || "", category:r.data.category || "General",
      content:r.data.content, status:r.data.status || "published"
    })).catch(()=>setError("Could not load post."));
  }, [id]);

  const submit = async e => {
    e.preventDefault();
    try {
      if (editing) await api.put(`/posts/${id}`, form);
      else await api.post("/posts", form);
      nav("/dashboard");
    } catch(err) { setError(err.response?.data?.message || "Could not save post."); }
  };

  return <div className="editor">
    <span className="eyebrow">{editing ? "EDIT STORY" : "NEW STORY"}</span>
    <h1>{editing ? "Refine your story" : "Write something worth reading"}</h1>
    {error && <div className="error">{error}</div>}
    <form onSubmit={submit} className="formCard">
      <input className="titleInput" placeholder="Post title" required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
      <input placeholder="Short excerpt" value={form.excerpt} onChange={e=>setForm({...form,excerpt:e.target.value})}/>
      <select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
        <option>Technology</option><option>Education</option><option>Programming</option><option>Career</option><option>Lifestyle</option><option>General</option>
      </select>
      <textarea className="contentInput" placeholder="Write your story here..." required value={form.content} onChange={e=>setForm({...form,content:e.target.value})}/>
      <select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option value="published">Published</option><option value="draft">Draft</option></select>
      <button className="button">{editing ? "Update Post" : "Publish Post"} →</button>
    </form>
  </div>;
}

function Dashboard() {
  const user = getUser();
  const [posts, setPosts] = useState([]);
  const load = () => api.get(`/posts/user/${user.id}`).then(r=>setPosts(r.data));
  useEffect(load, []);

  const remove = async id => {
    if (!confirm("Delete this post?")) return;
    await api.delete(`/posts/${id}`); load();
  };

  return <>
    <div className="sectionHead"><div><span className="eyebrow">YOUR WRITING</span><h2>Dashboard</h2></div><Link className="button small" to="/create">+ New post</Link></div>
    <div className="postGrid">
      {posts.map(p=><article className="postCard" key={p._id}><span className="tag">{p.category}</span><h3>{p.title}</h3><p>{p.excerpt || p.content.slice(0,120)}</p><div className="actions"><Link to={`/edit/${p._id}`}>Edit</Link><button className="delete" onClick={()=>remove(p._id)}>Delete</button></div></article>)}
    </div>
    {!posts.length && <div className="empty">You have not published any posts yet.</div>}
  </>;
}

function Profile() {
  const { id } = useParams();
  const [profile,setProfile] = useState(null);
  const [posts,setPosts] = useState([]);
  useEffect(()=>{Promise.all([api.get(`/users/${id}`),api.get(`/posts/user/${id}`)]).then(([u,p])=>{setProfile(u.data);setPosts(p.data)})},[id]);

  if (!profile) return <p>Loading profile...</p>;
  return <><div className="profile"><div className="avatar">{profile.name.charAt(0).toUpperCase()}</div><h1>{profile.name}</h1><p>{profile.bio || "BlogSphere writer"}</p><span>{profile.postCount} published posts</span></div><h2>Stories by {profile.name}</h2><div className="postGrid">{posts.map(p=><PostCard key={p._id} post={p}/>)}</div></>;
}

function Protected({ children }) {
  return getUser() ? children : <Auth />;
}

export default function App() {
  return <Layout><Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/login" element={<Auth/>}/>
    <Route path="/register" element={<Auth register/>}/>
    <Route path="/post/:id" element={<PostDetail/>}/>
    <Route path="/profile/:id" element={<Profile/>}/>
    <Route path="/dashboard" element={<Protected><Dashboard/></Protected>}/>
    <Route path="/create" element={<Protected><Editor/></Protected>}/>
    <Route path="/edit/:id" element={<Protected><Editor/></Protected>}/>
  </Routes></Layout>;
}

# BlogSphere - Full Stack Blogging Platform

A ready-to-run internship-level 2nd year B.Tech full-stack project.

## Technology Stack

Frontend:
- React
- Vite
- React Router
- Axios
- CSS

Backend:
- Node.js
- Express.js
- JWT authentication
- bcrypt password hashing
- Mongoose

Database:
- MongoDB

## Features

### Authentication
- User registration
- User login/logout
- JWT authentication
- Protected routes
- Password hashing with bcrypt

### Blog Posts
- View all published posts
- View a single post
- Create posts
- Edit own posts
- Delete own posts
- Draft/published status
- Search posts
- Category support

### Comments
- Logged-in users can comment
- Users can delete their own comments
- Comments show author and date

### User Profile
- View profile
- View user's published posts

### UI
- Responsive design
- Navigation bar
- Home page
- Post detail page
- Create/edit post form
- Login/register pages
- Profile page
- Dashboard
- Loading/error states

## Project Structure

blogging-platform/
├── backend/
│   ├── package.json
│   ├── .env.example
│   └── src/
│       ├── server.js
│       ├── config/db.js
│       ├── middleware/auth.js
│       ├── models/
│       │   ├── User.js
│       │   ├── Post.js
│       │   └── Comment.js
│       ├── routes/
│       │   ├── authRoutes.js
│       │   ├── postRoutes.js
│       │   ├── commentRoutes.js
│       │   └── userRoutes.js
│       └── utils/generateToken.js
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── api.js
│       └── styles.css
├── database/
│   └── schema.md
└── README.md

## Requirements

Install:
- Node.js 20+
- npm
- MongoDB Community Server OR MongoDB Atlas
- Git
- VS Code recommended

## Run Backend

Open terminal:

```bash
cd backend
npm install
```

Copy `.env.example` to `.env`.

Example:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/blogsphere
JWT_SECRET=replace-with-a-long-random-secret
CLIENT_URL=http://localhost:5173
```

Start:

```bash
npm run dev
```

Backend:
http://localhost:5000

## Run Frontend

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend:
http://localhost:5173

## API Endpoints

### Auth
POST /api/auth/register
POST /api/auth/login
GET /api/auth/me

### Posts
GET /api/posts
GET /api/posts/:id
POST /api/posts
PUT /api/posts/:id
DELETE /api/posts/:id
GET /api/posts/user/:userId

### Comments
GET /api/comments/post/:postId
POST /api/comments/post/:postId
DELETE /api/comments/:id

### Users
GET /api/users/:id

## Example Registration

```json
{
  "name": "Student User",
  "email": "student@example.com",
  "password": "Student@123"
}
```

## GitHub

```bash
git init
git add .
git commit -m "Initial blogging platform"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Deployment

### Backend
Suitable platforms:
- Render
- Railway
- AWS
- Fly.io

Set environment variables:
- MONGO_URI
- JWT_SECRET
- CLIENT_URL
- PORT

### Frontend
Suitable platforms:
- Vercel
- Netlify

Change the API base URL in `frontend/src/api.js` to the deployed backend URL.

## Security

Implemented:
- Password hashing
- JWT authentication
- Authorization for post ownership
- Authorization for comment deletion
- Helmet security headers
- CORS
- Express rate limiting
- Input validation
- MongoDB/Mongoose data validation
- No password returned in user responses

## Internship Presentation

Recommended modules to explain:
1. Requirement analysis
2. Architecture
3. Database design
4. Authentication
5. CRUD operations
6. REST API
7. React routing
8. API integration
9. Security
10. Testing
11. Git/GitHub
12. Deployment

## Future Enhancements

- Likes
- Bookmarks
- Rich text editor
- Image upload
- Admin dashboard
- Pagination
- Email verification
- Password reset
- Notifications
- Tags
- Analytics

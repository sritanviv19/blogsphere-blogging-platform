const mongoose = require("mongoose");

const postSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, minlength: 3, maxlength: 160 },
    content: { type: String, required: true, minlength: 10 },
    excerpt: { type: String, default: "", maxlength: 300 },
    category: { type: String, default: "General", trim: true },
    status: { type: String, enum: ["draft", "published"], default: "published" },
    author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Post", postSchema);

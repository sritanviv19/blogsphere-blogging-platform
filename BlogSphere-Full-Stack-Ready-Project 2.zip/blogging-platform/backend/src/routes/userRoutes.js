const express = require("express");
const User = require("../models/User");
const Post = require("../models/Post");

const router = express.Router();

router.get("/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) return res.status(404).json({ message: "User not found." });

    const postCount = await Post.countDocuments({ author: user._id, status: "published" });
    res.json({ id: user._id, name: user.name, bio: user.bio, postCount, createdAt: user.createdAt });
  } catch {
    res.status(400).json({ message: "Invalid user ID." });
  }
});

module.exports = router;

const express = require("express");
const Comment = require("../models/Comment");
const Post = require("../models/Post");
const protect = require("../middleware/auth");

const router = express.Router();

router.get("/post/:postId", async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .populate("author", "name")
      .sort({ createdAt: -1 });
    res.json(comments);
  } catch {
    res.status(500).json({ message: "Unable to load comments." });
  }
});

router.post("/post/:postId", protect, async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || !text.trim()) return res.status(400).json({ message: "Comment cannot be empty." });
    const post = await Post.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: "Post not found." });

    const comment = await Comment.create({
      text: text.trim(),
      author: req.user._id,
      post: post._id
    });

    res.status(201).json(await comment.populate("author", "name"));
  } catch {
    res.status(400).json({ message: "Could not add comment." });
  }
});

router.delete("/:id", protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: "Comment not found." });
    if (comment.author.toString() !== req.user._id.toString())
      return res.status(403).json({ message: "You can delete only your own comments." });

    await comment.deleteOne();
    res.json({ message: "Comment deleted." });
  } catch {
    res.status(400).json({ message: "Could not delete comment." });
  }
});

module.exports = router;

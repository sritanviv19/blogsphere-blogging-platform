const express = require("express");
const Post = require("../models/Post");
const protect = require("../middleware/auth");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const { search, category } = req.query;
    const filter = { status: "published" };

    if (category) filter.category = category;
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: "i" } },
        { content: { $regex: search, $options: "i" } }
      ];
    }

    const posts = await Post.find(filter)
      .populate("author", "name bio")
      .sort({ createdAt: -1 });

    res.json(posts);
  } catch {
    res.status(500).json({ message: "Unable to fetch posts." });
  }
});

router.get("/user/:userId", async (req, res) => {
  try {
    const posts = await Post.find({ author: req.params.userId, status: "published" })
      .populate("author", "name")
      .sort({ createdAt: -1 });
    res.json(posts);
  } catch {
    res.status(500).json({ message: "Unable to fetch user posts." });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate("author", "name bio");
    if (!post || post.status !== "published")
      return res.status(404).json({ message: "Post not found." });
    res.json(post);
  } catch {
    res.status(400).json({ message: "Invalid post ID." });
  }
});

router.post("/", protect, async (req, res) => {
  try {
    const { title, content, excerpt, category, status } = req.body;
    const post = await Post.create({
      title, content, excerpt, category,
      status: status === "draft" ? "draft" : "published",
      author: req.user._id
    });
    res.status(201).json(await post.populate("author", "name bio"));
  } catch {
    res.status(400).json({ message: "Could not create post." });
  }
});

router.put("/:id", protect, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    if (post.author.toString() !== req.user._id.toString())
      return res.status(403).json({ message: "You can edit only your own posts." });

    const allowed = ["title", "content", "excerpt", "category", "status"];
    allowed.forEach(key => {
      if (req.body[key] !== undefined) post[key] = req.body[key];
    });

    await post.save();
    res.json(await post.populate("author", "name bio"));
  } catch {
    res.status(400).json({ message: "Could not update post." });
  }
});

router.delete("/:id", protect, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    if (post.author.toString() !== req.user._id.toString())
      return res.status(403).json({ message: "You can delete only your own posts." });

    await post.deleteOne();
    res.json({ message: "Post deleted." });
  } catch {
    res.status(400).json({ message: "Could not delete post." });
  }
});

module.exports = router;
